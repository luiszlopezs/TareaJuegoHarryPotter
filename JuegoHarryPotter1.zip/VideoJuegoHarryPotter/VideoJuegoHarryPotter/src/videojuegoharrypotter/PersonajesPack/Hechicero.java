/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package videojuegoharrypotter.PersonajesPack;

import videojuegoharrypotter.HechizosPack.Hechizo;

/**
 *
 * @author Estudiantes
 */
public abstract class Hechicero {
    
    protected Hechizo hechizo;


    public abstract void hechizar();
    
    public void cambiarHechizo(Hechizo hc){
        hechizo = hc;
    }
    
    
    
}
