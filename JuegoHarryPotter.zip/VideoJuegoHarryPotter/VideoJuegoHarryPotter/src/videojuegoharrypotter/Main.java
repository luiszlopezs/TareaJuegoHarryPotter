/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package videojuegoharrypotter;

import java.util.Scanner;
import videojuegoharrypotter.HechizosPack.ExpectoPatronum;
import videojuegoharrypotter.HechizosPack.Expelliarmus;
import videojuegoharrypotter.HechizosPack.OculusReparo;
import videojuegoharrypotter.HechizosPack.WingardiumLeviosa;
import videojuegoharrypotter.PersonajesPack.HarryPotter;
import videojuegoharrypotter.PersonajesPack.Hechicero;
import videojuegoharrypotter.PersonajesPack.HermioneGranger;
import videojuegoharrypotter.PersonajesPack.RonWeasley;

/**
 *
 * @author Estudiantes
 */
public class Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Hechicero personaje = null;
        String hechizo = null;
        int opcion;

        do {
            System.out.println("\n=== MENÚ DE MAGIA ===");
            System.out.println("1. Elegir personaje");
            System.out.println("2. Hechizar");
            System.out.println("3. Cambiar hechizo");
            System.out.println("4. Cambiar personaje");
            System.out.println("5. Salir");
            System.out.print("Elige una opción: ");
            opcion = sc.nextInt();
            sc.nextLine(); // limpiar buffer

            switch (opcion) {
                case 1:
                case 4: // usar la misma lógica para elegir/cambiar personaje
                    System.out.println("\nElige un personaje:");
                    System.out.println("1. Hermione Granger");
                    System.out.println("2. Harry Potter");
                    System.out.println("3. Ron Weasley");
                    System.out.print("Opción: ");
                    int eleccion = sc.nextInt();
                    sc.nextLine(); // limpiar buffer

                    switch (eleccion) {
                        case 1:
                            System.out.println("Personaje elegido: Hermione Granger");
                            personaje = new HermioneGranger();
                            break;
                        case 2:
                            System.out.println("Personaje elegido: Harry Potter");
                            personaje = new HarryPotter();

                            break;
                        case 3:
                            System.out.println("Personaje elegido: Ron Weasley");
                            personaje = new RonWeasley();

                            break;
                        default:
                            System.out.println("Opción inválida, no se cambió el personaje.");
                    }

                    break;

                case 2:
                    if (personaje == null) {
                        System.out.println("Primero debes elegir un personaje.");
                    } else {
                        personaje.hechizar();
                    }
                    break;

                case 3:
                    if (personaje == null) {
                        System.out.println("Primero debes elegir un personaje.");
                    } else {
                        System.out.println("\nElige un hechizo:");
                        System.out.println("1. ExpectoPatronum");
                        System.out.println("2. Expelliarmus");
                        System.out.println("3. OculusReparo");
                        System.out.println("4. WingardiumLeviosa");
                        System.out.print("Opción: ");
                        int eleccion2 = sc.nextInt();
                        sc.nextLine(); // limpiar buffer

                        switch (eleccion2) {
                            case 1:
                                System.out.println("Hechizo elegido: ExpectoPatronum");
                                personaje.cambiarHechizo(new ExpectoPatronum());
                                break;
                            case 2:
                                System.out.println("Hechizo elegido: Expelliarmus");
                                personaje.cambiarHechizo(new Expelliarmus());

                                break;
                            case 3:
                                System.out.println("Hechizo elegido: OculusReparo");
                                personaje.cambiarHechizo(new OculusReparo());

                                break;
                            case 4:
                                System.out.println("Hechizo elegido: WingardiumLeviosa");
                                personaje.cambiarHechizo(new WingardiumLeviosa());

                                break;
                            default:
                                System.out.println("Opción inválida, no se cambió el hechizo.");
                        }

                    }
                    break;

                case 5:
                    System.out.println("¡Saliendo del juego de magia!");
                    break;

                default:
                    System.out.println("Opción inválida, intenta de nuevo.");
            }

        } while (opcion != 5);

        sc.close();
    }
}
