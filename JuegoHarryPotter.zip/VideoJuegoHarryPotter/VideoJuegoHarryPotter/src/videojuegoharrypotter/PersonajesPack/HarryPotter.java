/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package videojuegoharrypotter.PersonajesPack;

import videojuegoharrypotter.HechizosPack.ExpectoPatronum;

/**
 *
 * @author Estudiantes
 */
public class HarryPotter extends Hechicero{

    public HarryPotter() {
        this.hechizo = new ExpectoPatronum();
    }
    
    
    
    public void hechizar(){
        System.out.println("Harry Potter: " + this.hechizo.ejecutarHechizo());
    }
    
}
