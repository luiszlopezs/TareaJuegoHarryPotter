/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package videojuegoharrypotter.PersonajesPack;

import videojuegoharrypotter.HechizosPack.WingardiumLeviosa;

/**
 *
 * @author Estudiantes
 */
public class HermioneGranger extends Hechicero {

    public HermioneGranger() {
        this.hechizo = new WingardiumLeviosa();
    }

    @Override
    public void hechizar() {
        System.out.println("Hermione Granger: " + this.hechizo.ejecutarHechizo());
    }

}
